计 64	嵇天颖	2016010308

## LAB 2

[TOC]



---

### （〇）填写已有实验

> 本实验依赖实验1。请把你做的实验1的代码填入本实验中代码中有`“LAB1”`的注释相应部分。提示：可采用`diff`和`patch`工具进行半自动的合并`（merge）`，也可用一些图形化的比较`/merge`工具来手动合并，比如`meld`，`eclipse`中的`diff/merge`工具，`understand`中的`diff/merge`工具等。
>
> 请在实验报告中简要说明你的设计实现过程。

利用了`diffmerge`图形化比较工具实现了代码的合并。



### （一）实现 first-fit 连续物理内存分配算法

#### 【练习1.1】

> 在实现`first fit`内存分配算法的回收函数时，要考虑地址连续的空闲块之间的合并操作。提示:在建立空闲页块链表时，需要按照空闲页块起始地址来排序，形成一个有序的链表。可能会修改`default_pmm.c`中的`default_init，default_init_memmap，default_alloc_pages， default_free_pages`等相关函数。请仔细查看和理解`default_pmm.c`中的注释。

##### 设计思路和原理分析

`first_fit`算法相比于`bad_fit`和`best_fit`实现更为简单，效果也很好。我们知道在`UNIX`系统的最初版本中，就是使用`first_fit`算法为进程分配内存空间，但它是用数组的数据结构（而非链表）来实现，我们的`ucore`是用的双向链表实现的。当然它也有缺陷，`first_fit`算法会使得内存的低地址部分出现很多小的空闲分区，而每次分配查找时，都要经过这些分区。

（1）**`first_fit`分配算法原理**：空闲分区以地址递增的次序链接。分配内存时顺序查找，找到大小能满足要求的第一个空闲分区。

（2）**数据结构分析**：`first_fit`分配算法需要维护一个查找有序（地址按从小到大排列）空闲块（以页为最小单位的连续地址空间的数据结构，`ucore`中选择了双向链表。

根据注释的提示，我们需要了解`libs/list.h`中定义的通用双向链表的结构和`memlayout.h`中定义的`free_area_t`的数据结构。

**分析`lib/list.h`**

我们不妨来观察`ucore`中提供的通用双向链表结构，因为在实现`first_fit`算法中我们需要使用它提供的一系列操作的服务。

首先是结构体的定义，提供了前向和后向两个指针。

~~~c
struct list_entry {
    struct list_entry *prev, *next;
};
typedef struct list_entry list_entry_t;
~~~

接着定义了对双向链表的操作，如初始化，插入，删除，跳到下一个或上一个元素，判断链表是否为空之类。

我们下面会使用到的有： `list_init`, `list_add`(`list_add_after`), `list_add_before`, `list_del`, `list_next`, `list_prev`

~~~c
static inline void list_init(list_entry_t *elm) __attribute__((always_inline));
static inline void list_add(list_entry_t *listelm, list_entry_t *elm) __attribute__((always_inline));
static inline void list_add_before(list_entry_t *listelm, list_entry_t *elm) __attribute__((always_inline));
static inline void list_add_after(list_entry_t *listelm, list_entry_t *elm) __attribute__((always_inline));
static inline void list_del(list_entry_t *listelm) __attribute__((always_inline));
static inline list_entry_t *list_next(list_entry_t *listelm) __attribute__((always_inline));
static inline list_entry_t *list_prev(list_entry_t *listelm) __attribute__((always_inline));
~~~



**分析`kern/mm/memlayout.h`中`free_area_t`结构体**

我们可以利用`free_area_t`来进行对空闲块的管理

~~~c
/* free_area_t - maintains a doubly linked list to record free (unused) pages */
typedef struct {
    list_entry_t free_list;         // the list header
    unsigned int nr_free;           // # of free pages in this free list
} free_area_t;
~~~



##### 代码与过程分析

> 首先我们分析四个函数中不需要重写的部分函数

**（1）`default_init`函数**

我们直接利用`lab 2`中提供好的`default_init`函数来初始化空闲块。

 `free_list` 是用来记录空闲块的双向链表（创建一个空链表）。

 `nr_free`记录了空闲块的总数量（置为0）。

~~~c
static void
default_init(void) {
    list_init(&free_list);
    nr_free = 0;
}
~~~

**(2) `default_init_memmap`函数**

`default_init_memmap`根据现有的内存情况来构建空闲块列表的初始状态。

代码之间的调用关系如下：

~~~c
kern_init --> pmm_init --> page_init --> init_memmap --> pmm_manager --> init_memmap
~~~

我们知道这个函数是根据每个物理页帧的情况来建立空闲链表，并且空闲块是一个按地址高低排序的链表。

链表头是`free_area.free_list`，链表项是`Page`数据结构`base_page_link`。

~~~c
static void
default_init_memmap(struct Page *base, size_t n) {
    assert(n > 0);
    struct Page *p = base;
    for (; p != base + n; p ++) {
        assert(PageReserved(p));
        p->flags = p->property = 0;
        set_page_ref(p, 0);
    }
    base->property = n;
    SetPageProperty(base);
    nr_free += n;
    list_add_before(&free_list, &(base->page_link));
}
~~~



> 在`kern/mm/default_pmm.c`中，主要改动了`default_alloc_pages`和`default_free_pages`两个函数。

**（1）`default_alloc_pages`函数**

首先考虑边界情况以保证代码的鲁棒性。检查要分配的n个页有没有超出空闲空间范围：

~~~c
static struct Page *
default_alloc_pages(size_t n) {
    assert(n > 0);
    if (n > nr_free) {
        return NULL;
    }
~~~

接着我们寻找第一个长度大于等于n的块

~~~c
struct Page *page = NULL;
list_entry_t *le = &free_list;
//(1)find the first block no shorter than n
while ((le = list_next(le)) != &free_list) {
    struct Page *p = le2page(le, page_link);
    if (p->property >= n) {
        page = p;
        break;
    }
}
~~~

* 如果可以找到长度大于等于`n`的块，则那么将该内存块中的对于分配的项，设置标志表明它们已经被使用，在空闲页列表里删除当前页。如果当前空闲块的页数大于`n`，那么分配`n`个页后剩下的第一个页为新的块的形状，它的`property`比原来的小`n`。（**见下面注释**）

  ~~~c
     if (page != NULL) {
          if (page->property > n) {				//如果当前的优先级大于n
              struct Page *p = page + n;
              p->property = page->property - n;	//重新计算优先级
              SetPageProperty(p); 				//重新设置优先级
              list_add_after(&(page->page_link), &(p->page_link));
      }
          list_del(&(page->page_link)); 			//删除当前页
          nr_free -= n;							//更新空闲块数量
          ClearPageProperty(page);
      }
  ~~~

返回找到的`page`

~~~c
    return page;
}
~~~



**（2）`default_free_pages`函数**

**思路**

`default_free_pages`函数是`default_alloc_pages`函数的逆过程.。

将需要释放的空间标记为空之后，需要找到空闲表中合适的位置。由于空闲表中的记录都是按照物理页地址排序的，所以如果插入位置的前驱或者后继刚好和释放后的空间邻接，那么需要将新的空间与前后邻接的空间合并形成更大的空间。

对前方和后方可能出现的连续空闲块进行合并时就需要从头开始搜索`free_list`链表，找到和释放空间可以拼接的前一块和后一块，此时需要注意依然要保持顺序性。

`property`位当该`Page`处于`free_list`中时有效，代表了该`block`中闲置页的个数（包括当前页），而`flags`中的`property`位则被主要用作判断页是否已经被占用。

**代码**

断言`n>0`方便快速检查

~~~c
static void
default_free_pages(struct Page *base, size_t n) {
    assert(n > 0);
    struct Page *p = base;
~~~

首先检查每个块中的各个`page property`是否合法

~~~ c
for (; p != base + n; p ++) {
    assert(!PageReserved(p) && !PageProperty(p));
    p->flags = 0;
    set_page_ref(p, 0);
}
~~~

然后设置好释放空间的长度和`page property`

~~~c
base->property = n;
SetPageProperty(base);
~~~

找到插入链表的位置（链表已按照地址从大到小排序）

~~~c
list_entry_t *le = list_next(&free_list);
list_entry_t *prev = &free_list;   
while (le != &free_list) {
    p = le2page(le, page_link);
    if (base < p) {
        break;
    }
    prev = le;
    le = list_next(le);
}
~~~

检查是否可以和链表的前一项中的空间合并

~~~c
p = le2page(prev, page_link);
if (prev != &free_list && p + p -> property == base) {
    p -> property += base -> property;
    ClearPageProperty(base);
} else {
    list_add_after(prev, &(base -> page_link));
    p = base;
}
~~~

检查是否可以和链表的后一项中的空间合并

~~~c
    struct Page *nextp = le2page(le, page_link);
    if (le != &free_list && p + p -> property == nextp) {
        p -> property += nextp -> property;
        ClearPageProperty(nextp);
        list_del(le);
    }
    nr_free += n;
}
~~~



#### 【练习1.2】

> 你的first fit算法是否有进一步的改进空间？

**（1）优化有序链表插入**

我们发现链表查找和有序链表插入是有&Omicron;(n)的复杂度。

在特殊情况下我们可以优化有序链表插入。比如在下面的情况中，对于一个刚刚被释放的内存，加入它的邻接空间都是空闲的，我们是无须对它进行链表插入操作的，而是直接合并到邻接空间中，这样的话复杂度是&Omicron;(1)。

如果要实现这种优化的话，我们要同时在第一个页面和最后一个页面都保存空闲块的信息，这样一来，新的空闲块只需要检查邻接的两个页面就能判断邻接空间块的状态。

**（2）优化链表查找**

我们发现链表查找也是有&Omicron;(n)的复杂度。

如果在每一块连续内存的头指针中，增加一个保存指向这段连续内存的末页的指针变量，则在分配内存查找满足条件的内存块时，遇到空间不够的内存块可以直接跳跃到其末页再继续查找，而不需要依次遍历这段内存块的内部。同样的道理，释放内存后，被释放的内存块在向前合并时，如果在每一块连续内存的末页保存其块大小，同样可以直接完成合并而不需要依次遍历。

**（3）换数据结构**

可以用各种树状结构来代替双向链表实现操作。查找的时候比如进行二分查找，可以优化到&Omicron;(logn)





---

### （二）实现寻找虚拟地址对应的页表项

#### 【练习2.1】

> 通过设置页表和对应的页表项，可建立虚拟内存地址和物理内存地址的对应关系。其中的get_pte函数是设置页表项环节中的一个重要步骤。此函数找到一个虚地址对应的二级页表项的内核虚地址，如果此二级页表项不存在，则分配一个包含此项的二级页表。本练习需要补全get_pte函数 in kern/mm/pmm.c，实现其功能。请仔细查看和理解get_pte函数中的注释。

##### 设计思路与原理分析

（1）**原理分析**：

* 为了能够建立正确的地址映射关系，我们的`lab2`在链接阶段生成了`ucore`执行代码的虚地址，然后`bootloader`与`ucore`一起在运行时处理地址映射，最终实现段页式映射关系`virt addr = liner addr = phy addr +0xC0000000`。从`tools/kernel.ld`文件中我们得知`lab2`形成`ucore`的起始虚拟地址是从`0xC0100000`开始。
* 系统采用了二级页表来建立线性地址与物理地址之间的映射关系。`default_pmm_manager`是我们的物理内存管理器，我们用它来实现动态分配和释放内存页的功能，我们也可以用它来获得所需要的空闲物理页。
* 系统执行中地址映射分为三个阶段：
  * 第一个阶段是开启保护模式，创建启动段表：这里虚拟地址、线性地址以及物理地址之间的映射关系与`lab1`的一样。
  * 第二个阶段是创建初始页目录表，开启分页模式：这个阶段更新映射关系的同时将运行中的内核（EIP）从低虚拟地址“迁移”到高虚拟地址，而不造成伤害。
  * 第三个阶段是完善段表和页表：`pmm_init`函数将页目录表项补充完成（扩充到`0~KMEMSIZE`）。然后，更新段映射机制，使用一个新的段表。新段表除了包括内核态的代码段和数据段描述符，还包括用户态的代码段和数据段描述符以及`TSS`段的描述符。

（2）**设计思路**：

首先要查询一级页表，根据线性地址`la`在一级页表`pgdir`中寻找二级页表的起始地址。如果二级页表不存在，那么要根据参数`create`来判断是否分配二级页表的内存空间，若不分配则返回空。

`get_pte`函数是通过`PDT`的基址`pgdir`和线性地址`la`来获取`pte`。`PDX`根据`la`获取其页目录的索引，根据此索引可以得到页目录项`pde`，由于可能对其进行修改，这里采用指向`pde`的指针`pdep`，而`*pdep`中保存的便是`pde`的真实内容。创建了`pde`后，需要返回的值是`pte`的指针，这里先将`pde`中的地址转化为程序可用的虚拟地址。将这个地址转化为`pte`数据类型的指针，然后根据`la`的值索引出对应的`pte`表项。



##### 代码及实现分析

* 如果原本就有二级页表，或者新建立了页表，则只需返回对应项的地址即可

  ~~~c
  if (!(pgdir[PDX(la)] & PTE_P)) {
      //......
  }
  return (pte_t *)KADDR(PDE_ADDR(pgdir[PDX(la)])) + PTX(la);
  ~~~

* 如果发现对应的二级页表不存在，那么我们需要根据参数`create`的值来处理是否创建新的二级页表

  * 如果`create`的参数为0，则`get_pte`返回`NULL`

  * 如果`create`的参数不为0

    * 我们通过`alloc_page`来实现申请一个新的物理页的操作

    ~~~c
    struct Page *page;
    if (!create || (page = alloc_page()) == NULL)
        return NULL;
    ~~~

    * 再在一级页表中添加页目录项执行表示二级页表的新物理页(**代码解释见下面代码的注释**)

      设一个`32bit`线性地址`la`有一个对应的`32bit`物理地址`pa`，如果在以`la`的高`10`位为索引值的页目录项中的存在位`（PTE_P）`为`0`，表示缺少对应的页表空间，则可通过`alloc_page`获得一个空闲物理页给页表，页表起始物理地址是按`4096`字节对齐的，这样填写页目录项的内容为`页目录项内容 = (页表起始物理地址 & ~0x0FFF) | PTE_U | PTE_W | PTE_P`

    ~~~c
    	//set page reference
        set_page_ref(page, 1);
    	//get linear address of page
        uintptr_t pa = page2pa(page);
    	//clear page content using memset
        memset(KADDR(pa), 0, PGSIZE);
    	//set page directory entry's permission
        pgdir[PDX(la)] = (pa & ~0xFFF) | PTE_P | PTE_W | PTE_U;
    }
    ~~~



#### 【练习2.2】

> 请描述页目录项`（Page Directory Entry）`和页表项`（Page Table Entry）`中每个组成部分的含义以及对`ucore`而言的潜在用处。

**（1）查阅资料**

`pde`和`pte`本身占用的存储空间为`32`位，可以当做`32`位整型处理。

查阅资料我们知道，`pde`的各个组成部分为：

~~~c
31 ----------------- 10 11 -- 9 8 7 6 5 4 3 2 1 0
  4KB对齐的页表起始地址      Avai. G S 0 A D W U R P
~~~

其中`31-10`位地址为必须，`avai`可以由软件自由修改，不受`kernel`或硬件的控制。考虑到`uCore`的`page`大小统一，不存在更换情况，所以`S`位对`uCore`无用。

`pte`的各个组成部分为：

~~~
31 ----------------- 10 11 -- 9 8 7 6 5 4 3 2 1 0
      物理页的地址         Avai.  G 0 D A C W U R P
~~~



**（2）观察代码**

我们从`mmh.h`中观察`PDE`和`PTE`的内容定义，其中列出了页目录项和页表项的入口标志字段。

因为页的映射是以物理页面为单位进行，所以页面对应的物理地址总是按照`4096`字节对齐的，物理地址低`0-11`位总是零，所以在页目录项和页表项中，低`0-11`位可以用于作为标志字段使用。(**下面注释写出了作用**)

~~~c
/* page table/directory entry flags */
#define PTE_P           0x001                   // 当前项是否存在，用于判断缺页
#define PTE_W           0x002                   // 当前项是否可写，标志权限
#define PTE_U           0x004                   // 用户是否可获取，标志权限
#define PTE_PWT         0x008                   // 写直达缓存机制,硬件使用Write Through
#define PTE_PCD         0x010                   // 禁用缓存，硬件使用Cache-Disable
#define PTE_A           0x020                   // 访问标志（Accessed）
#define PTE_D           0x040                   // 页是否被修改，硬件使用（dirty)
#define PTE_PS          0x080                   // 页大小
#define PTE_MBZ         0x180                   // 必须为0的位
#define PTE_AVAIL       0xE00                   // 软件使用的位，可任意设置            
~~~

高`12-31`位是`Page Table 4KB Aligned Address`，也就是对应的页表地址。



**（3）总结**

* `pde`的各个组成部分用途为：
  - `A, D, W`：这些与高速缓存相关的位，记录该页是否被访问过、不允许高速缓存过或执行了写穿透策略。如果`uCore`需要与硬件的`cache`进行交互（即这些位并非由硬件设定），就需要用到这些位。
  - `U`：决定了当前页的访问权限（内核`or`用户）：`uCore`可以通过这些位进行用户态和内核态程序访问权限的控制。
  - `R`：决定了当前页的是否可写属性：当`uCore`需要对某一页进行保护的时候，需要用到此位。用于权限控制
  - `P`：决定当前页是否存在：`uCore`需要根据这个标志确定页表是否存在，并是否建立新的相关页表，至关重要。

* `pte`的各个组成部分用途为（许多位与`pde`相同，下面列举的是不同的位）：
  - `C`：与上述的`D`位相同。
  - `G`：控制TLB地址的更新策略。
  - `D`：该页是否被写过。如果`uCore`需要对高速缓存实现更复杂的控制则可能用到该位。同时，在页换入或是换出的时候可能需要判断是否更新高速缓存。



#### 【练习2.3】

> 如果`ucore`执行过程中访问内存，出现了页访问异常，请问硬件要做哪些事情？

（1）将引发页访问异常的地址将被保存在cr2寄存器中
（2）设置错误代码
（3）引发`Page Fault`





---

### （三）释放某虚地址所在的页并取消对应二级页表项的映射

#### 【练习3.1】

> 当释放一个包含某虚地址的物理内存页时，需要让对应此物理内存页的管理数据结构`Page`做相关的清除处理，使得此物理内存页成为空闲；另外还需把表示虚地址与物理地址对应关系的二级页表项清除。请仔细查看和理解`page_remove_pte`函数中的注释。为此，需要补全在 `kern/mm/pmm.c`中的`page_remove_pte`函数。

**设计思路**

（1）首先我们讨论取消页表映射过程，我们需要将物理页的引用数目减一，如果变为零，那么释放页面；然后再将页目录项清零；最后我们还需要刷新TLB。

（2）根据上述思路我们需要做的：我们主要要实现page_remove_pte函数来完成取消页表映射的功能，因此我们先释放`la`地址所指向的页，并设置对应的`pte`的值。首先我们要确保页存在,找到`pte`所在的页,把`pte`所在页的`ref`减一。如果该页`ref`为0，则释放`pte`所在的页，再清空`TLB`。



**实验代码**

根据注释提示的步骤，我们可以写出下面的代码（**步骤注释见下面**）

~~~c
//(1) check if this page table entry is present
if (*ptep & PTE_P) { 
    	//(2) find corresponding page to pte
        struct Page *page = pte2page(*ptep); 
    	//(3) decrease page reference
        page_ref_dec(page);
    	//(4) and free this page when page reference reachs 0
        if (page -> ref == 0) {
            free_page(page);
        }
    	///(5) clear second page table entry
        *ptep = 0;
    	//(6) flush tlb
        tlb_invalidate(pgdir, la);
    }
~~~



#### 【练习3.2】

> 数据结构`Page`的全局变量（其实是一个数组）的每一项与页表中的页目录项和页表项有无对应关系？如果有，其对应关系是啥？

对应关系是：页目录项保存的物理页面地址（即某个页表）以及页表项保存的物理页面地址都对应于Page数组中的某一页。

具体而言，就是页目录项和页表项中都保存着一个物理页面的地址，对于页目录项，这个物理页面是页表的地址，对于页表，这个物理页面表示已经分配的物理页。每一个物理页面在`Page`数组中都有相应的记录，保存着该物理页是否被分配，被引用的数量和是否被内核保留等信息。



#### 【练习3.3】

> 如果希望虚拟地址与物理地址相等，则需要如何修改`lab2`，完成此事？

**设计原理与思路**

（1）**设计原理**

参考实验指导书中“系统执行中地址映射的四个阶段”一节，我们知道地址映射的建立分为多个阶段完成，所以针对不同的阶段需要修改不同的代码以使得虚拟地址和物理地址相等。

* 第一阶段是在`Bootloader`阶段，因为此时线性地址与物理地址相等，所以无需对这一阶段进行修改；
* 第二阶段是从`kern_entry`到`enable_paging`函数，主要采用段机制进行地址映射，需要修改的地方为`init/entry.S`中的`gdt`表项，去除`KERNBASE`有关的定义。此外，还需要修改`ucore`的链接脚本，将`ucore`起始的虚拟地址由`0xC0100000`改为`0x00100000`。
* 第三阶段是从`enable_paging`函数开始到`gdt_init`函数，虽然启动了页机制但是未更新段映射，这个时候页机制和段机制对于`0xC0000000`的偏移是叠加的。由于上一阶段已经修改过段机制的代码，这里仅需要将`boot_map_segment`函数调用的`KERNBASE`参数改为`0`，并取消`VPT`的递归自映射。这种情况下也没有必要专门建立`0-4M`物理地址映射，因为即使偏移叠加物理地址和虚拟地址还是相等的（最后有更详细的解释）。
* 第四阶段之后的阶段由于完全启用了页机制，且页机制的相关参数已经在上一步设置完毕，所以我们无需修改，虚拟地址已经与物理地址相等。

（2）**设计思路**

**STEP 1：**由于在段机制启动前，虚拟地址和线性地址之间存在`0xC0100000`的偏差，而在段机制启动后会消除这部分偏差，所以首先第一步我们要将这个偏差抹去，并且在接来下的一步中也不去消除此偏差。

**STEP 2：**另外，页机制也会使得线性地址和物理地址之间存在`0xC0100000`的偏差，由于第二步的操作，这个偏差已经被消除了。

**STEP 3：**但是，在未消除偏差时，线性地址的低`4M`空间是需要直接映射到对应的物理地址的，而不应该产生偏移，所以会有第`3`步中需要注释的那些代码。现在由于页机制产生的线性地址和物理地址之间的偏差已经被消除了，这些代码也不需要了，因此要注释掉。



**代码设计**

（1）更改链接脚本`tools/kernel.ld`，将虚拟地址改为`0x100000`：

~~~c
SECTIONS {
  /* Load the kernel at this address: "." means the current address */
  . = 0x0100000;
~~~

（2）把`kernel`基地址改回`0`：

~~~c
/* All physical memory mapped at this address */
#define KERNBASE            0x00000000
~~~

（3）注释掉取消`0~4M`区域内存页映射的代码

~~~c
//disable the map of virtual_addr 0~4M
// boot_pgdir[0] = 0;
~~~



#### 【make grade 结果】

![](./figs/makegrade.png)

---

### （四）与参考答案的实现区别

（1）**练习1**：代码实现有所区别，已经在相应的小节中体现说明；

（2）**练习2和练习3**：练习2和3是根据注释提示的步骤编写代码，所以实现逻辑基本相同，但具体细节还是有所不同的，详见相应小节。



---

### （五）本实验中重要的OS知识点

**(1)连续分配管理方式**

如果内存中有多个足够大的空闲块，操作系统必须确定分配那个内存块给进程使用，这就是动态分区的分配策略。一般是有以下几种算法：

1）首次适应算法：空闲分区以地址递增的次序链接。分配内存时顺序查找，找到大小能满足要求的第一个空闲分区。

2）最佳适应算法：空闲分区按容量递增形成分区链，找到第一个能满足要求的空闲分区。

3）最坏适应算法：有称最大适应算法，空闲分区以容量递减次序链接。找到第一个能满足要求的空闲分区，也就是挑选最大的分区。

4）临近适应算法：又称循环首次适应算法，由首次适应算法演变而成。不同之处是分配内存时从此查找结束的位置开始继续查找。

**（2）段页式管理**

`x86` 体系结构将内存地址分成三种：逻辑地址（也称虚地址）、线性地址和物理地址。逻辑地址即是程序指令中使用的地址，物理地址是实际访问内存的地址。逻 辑地址通过段式管理的地址映射可以得到线性地址，线性地址通过页式管理的地址映射得到物理地址。

在` ucore `中段式管理只起到了一个过渡作用，它将逻辑地址不加转换直接映射成线性地址。页式管理将线性地址分成三部分。

**（3）系统执行中地址映射的三个阶段**

**第一个阶段**（开启保护模式，创建启动段表）

**第二个阶段**（创建初始页目录表，开启分页模式）

**第三个阶段**（完善段表和页表）



---

### （六）实验中没有体现的知识点

**碎片整理**

碎片整理是通过调整进程占用的分区位置来减少或避免分区碎片。

如果所有的应用程序是可动态重定位的，可以通过移动分配给进程的内存分区，以合并外部碎片。

还可以进行分区对换，通过抢占并回收处于等待状态进程的分区，以增大可用内存空间。

